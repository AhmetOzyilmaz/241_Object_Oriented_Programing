public class SmallCell {
    int posX = 0;
    int posY = 0;
    String CellCounter = new String();

    public SmallCell(int i, int j, String s) {
        posX = i; posY = j; CellCounter = s;
    }
}
